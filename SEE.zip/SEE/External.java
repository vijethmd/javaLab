package SEE;

import CIE.Personal;

public class External extends Personal {
    public int[] externalMarks;

    public External(String usn, String name, int sem, int[] marks) {
        super(usn, name, sem);
        if (marks.length == 5) {
            this.externalMarks = marks;
        } else {
            throw new IllegalArgumentException("Marks array must have exactly 5 elements.");
        }
    }
}